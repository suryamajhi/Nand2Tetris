import java.io.*;

public class CodeWriter {
    private int label = 0;
    private final String fileName;
    private final PrintWriter pw;
    private String assembly = "";
    public CodeWriter(String fileName) throws IOException {
        this.fileName = fileName;
        if(fileName.contains("/")){
            int i = fileName.lastIndexOf("/");
            fileName = fileName.substring(i+1);
        }
        pw = new PrintWriter(new FileWriter(new File("asm_files\\"+fileName+".asm")));
    }
    public void writeArithmetic(String command){
        pw.println("//"+command);
        switch (command) {
            case "add": assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nMD=D+M";break;
            case "sub": assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nMD=M-D";break;
            case "neg": assembly = "@SP\nA=M-1\nD=M\nM=-D";break;
            case "eq" : assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\n@LABEL"+ label+ "\nD;JEQ\n@SP\nA=M-1\nM=0\n@LABEL"+label+"\nD=A\n@3\nA=D+A\n0;JMP\n(LABEL"+label+")\n@SP\nA=M-1\nM=-1"; label++;break;
            case "gt" : assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\n@LABEL"+ label+ "\nD;JGT\n@SP\nA=M-1\nM=0\n@LABEL"+label+"\nD=A\n@3\nA=D+A\n0;JMP\n(LABEL"+label+")\n@SP\nA=M-1\nM=-1"; label++;break;
            case "lt" : assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\n@LABEL"+ label+ "\nD;JLT\n@SP\nA=M-1\nM=0\n@LABEL"+label+"\nD=A\n@3\nA=D+A\n0;JMP\n(LABEL"+label+")\n@SP\nA=M-1\nM=-1"; label++;break;
            case "or" : assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nMD=D|M";break;
            case "and": assembly = "@SP\nAM=M-1\nD=M\nA=A-1\nMD=D&M";break;
            case "not": assembly = "@SP\nA=M-1\nD=M\nM=!D";break;
        }
        pw.println(assembly);
    }
    public void writePushPop(String commandType,String segment,int index){
        if(commandType.equals("C_PUSH")){
            switch (segment){
                case "constant": assembly = "@"+index+"\nD=A\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "local"   : assembly = "@"+index+"\nD=A\n@LCL\nD=M+D\n@R13\nM=D\n@R13\nA=M\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "argument": assembly = "@"+index+"\nD=A\n@ARG\nD=M+D\n@R13\nM=D\n@R13\nA=M\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "static"  : assembly = "@"+fileName+"."+index+"\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "temp"    : assembly = "@"+index+"\nD=A\n@5\nD=D+A\n@R13\nM=D\n@R13\nA=M\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "this"    : assembly = "@"+index+"\nD=A\n@THIS\nD=M+D\n@R13\nM=D\n@R13\nA=M\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "that"    : assembly = "@"+index+"\nD=A\n@THAT\nD=M+D\n@R13\nM=D\n@R13\nA=M\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";break;
                case "pointer":{
                    if(index == 0){
                        assembly = "@THIS\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";
                    }else{
                        assembly = "@THAT\nD=M\n@SP\nA=M\nM=D\n@SP\nD=M\nM=D+1";
                    }
                    break;
                }
            }
        }
        if(commandType.equals("C_POP")){
            switch (segment){
                case "local"   : assembly = "@"+index+"\nD=A\n@LCL\nD=M+D\n@R13\nM=D\n@SP\nAM=M-1\nD=M\n@R13\nA=M\nM=D";break;
                case "argument": assembly = "@"+index+"\nD=A\n@ARG\nD=M+D\n@R13\nM=D\n@SP\nAM=M-1\nD=M\n@R13\nA=M\nM=D";break;
                case "static"  : assembly = "@SP\nAM=M-1\nD=M\n@"+fileName+"."+index +"\nM=D";break;
                case "temp"    : assembly = "@"+index+"\nD=A\n@5\nD=D+A\n@R13\nM=D\n@SP\nAM=M-1\nD=M\n@R13\nA=M\nM=D";break;
                case "this"    : assembly = "@"+index+"\nD=A\n@THIS\nD=M+D\n@R13\nM=D\n@SP\nAM=M-1\nD=M\n@R13\nA=M\nM=D";break;
                case "that"    : assembly = "@"+index+"\nD=A\n@THAT\nD=M+D\n@R13\nM=D\n@SP\nAM=M-1\nD=M\n@R13\nA=M\nM=D";break;
                case "pointer":{
                    if(index==0){
                        assembly = "@SP\nM=M-1\nA=M\nD=M\n@THIS\nM=D";
                    }else{
                        assembly = "@SP\nM=M-1\nA=M\nD=M\n@THAT\nM=D";
                    }
                }
            }
        }
        pw.println("//"+commandType+" "+segment+ " "+ index);
        pw.println(assembly);
    }
    public void close(){
        pw.close();
    }
}