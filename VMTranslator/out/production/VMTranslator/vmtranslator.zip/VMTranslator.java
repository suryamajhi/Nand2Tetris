import java.io.*;
import java.util.Scanner;

public class VMTranslator {
    public static void main(String[] args) throws IOException {
        String vmFile = args[0];
        String fileName = vmFile.substring(vmFile.lastIndexOf("\\")+1,vmFile.indexOf("."));
        BufferedReader in = new BufferedReader(new FileReader(new File(vmFile)));
        Scanner scanner = new Scanner(in);
        CodeWriter cw = new CodeWriter(fileName);
        new Parser(scanner,cw);
    }
}
