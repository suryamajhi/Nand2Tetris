import java.util.ArrayList;
import java.util.Scanner;

public class Parser {
    private String currentCommand;
    private final Scanner scanner;
    private final CodeWriter cw;
    private final ArrayList<String> arithmeticCommands;
    private String commandType;
    private String[] commandSplits = new String[3];

    public Parser(Scanner scanner, CodeWriter cw) {
        this.scanner = scanner;
        this.cw = cw;
        arithmeticCommands = new ArrayList<>();
        arithmeticCommands();
        while (hasMoreCommand()) {
            advance();
        }
        cw.close();
    }

    private boolean hasMoreCommand(){
        return scanner.hasNextLine();
    }

    private void advance(){
        currentCommand  = scanner.nextLine();
        if (currentCommand.startsWith("//")|| currentCommand.isEmpty()) return;
        commandSplits = currentCommand.split(" ");
        commandType = commandType();
        if(commandType.equals("C_ARITHMETIC")) {
            cw.writeArithmetic(arg1());
        }
        else if(commandType.equals("C_PUSH")||commandType.equals("C_POP")){
            cw.writePushPop(commandType,arg1(),arg2());
        }
    }

    private String commandType(){
        if(arithmeticCommands.contains(currentCommand))
            return "C_ARITHMETIC";
        else{
            if(commandSplits[0].equals("push")) return "C_PUSH";
            else if(commandSplits[0].equals("pop")) return "C_POP";
            return null;
        }
    }

    private String arg1(){
        if(commandType.equals("C_ARITHMETIC"))
            return commandSplits[0];
        else if(commandType.equals("C_PUSH")||commandType.equals("C_POP"))
            return commandSplits[1];
        else
            return commandSplits[0];
    }
    private int arg2(){
        return Integer.parseInt(commandSplits[2]);
    }

    private void arithmeticCommands(){
        arithmeticCommands.add("add");
        arithmeticCommands.add("sub");
        arithmeticCommands.add("neg");
        arithmeticCommands.add("eq");
        arithmeticCommands.add("gt");
        arithmeticCommands.add("lt");
        arithmeticCommands.add("and");
        arithmeticCommands.add("or");
        arithmeticCommands.add("not");
    }
}
